import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmintechnoComponent } from './admintechno.component';

describe('AdmintechnoComponent', () => {
  let component: AdmintechnoComponent;
  let fixture: ComponentFixture<AdmintechnoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmintechnoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmintechnoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
