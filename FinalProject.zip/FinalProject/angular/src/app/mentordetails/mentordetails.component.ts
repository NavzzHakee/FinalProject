import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentordetails',
  templateUrl: './mentordetails.component.html',
  styleUrls: ['./mentordetails.component.css']
})
export class MentordetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
