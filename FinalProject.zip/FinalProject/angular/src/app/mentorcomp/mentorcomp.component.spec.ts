import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorcompComponent } from './mentorcomp.component';

describe('MentorcompComponent', () => {
  let component: MentorcompComponent;
  let fixture: ComponentFixture<MentorcompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorcompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
