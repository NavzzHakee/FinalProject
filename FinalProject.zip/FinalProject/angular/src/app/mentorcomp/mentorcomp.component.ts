import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-mentorcomp',
  templateUrl: './mentorcomp.component.html',
  styleUrls: ['./mentorcomp.component.css']
})
export class MentorcompComponent implements OnInit {

 
  constructor(private httpservice : HttpClient) { }

  course : string[];


  ngOnInit() {
    this.httpservice.get('../../assets/mentorcom.json').subscribe(

      data=>{
        this.course = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }

}