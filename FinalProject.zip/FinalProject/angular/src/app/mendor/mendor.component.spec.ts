import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MendorComponent } from './mendor.component';

describe('MendorComponent', () => {
  let component: MendorComponent;
  let fixture: ComponentFixture<MendorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MendorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MendorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
