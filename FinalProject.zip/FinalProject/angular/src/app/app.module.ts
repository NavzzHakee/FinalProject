import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminmentordataComponent } from './adminmentordata/adminmentordata.component';
import { AdmintechnoComponent } from './admintechno/admintechno.component';
import { AdminuserdataComponent } from './adminuserdata/adminuserdata.component';
import { CompleteddetailsComponent } from './completeddetails/completeddetails.component';
import { CoursedetailsComponent } from './coursedetails/coursedetails.component';
import { CurrentdetailsComponent } from './currentdetails/currentdetails.component';
import { DevelopmentComponent } from './development/development.component';
import { EditskillComponent } from './editskill/editskill.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { MendorComponent } from './mendor/mendor.component';
import { MentorcompComponent } from './mentorcomp/mentorcomp.component';
import { MentorcurrentComponent } from './mentorcurrent/mentorcurrent.component';
import { MentordetailsComponent } from './mentordetails/mentordetails.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { PayComponent } from './pay/pay.component';
import { UserComponent } from './user/user.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { LoginpageComponent } from './loginpage/loginpage.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AdmindetailsComponent,
    AdminmentordataComponent,
    AdmintechnoComponent,
    AdminuserdataComponent,
    CompleteddetailsComponent,
    CoursedetailsComponent,
    CurrentdetailsComponent,
    DevelopmentComponent,
    EditskillComponent,
    MainpageComponent,
    MendorComponent,
    MentorcompComponent,
    MentorcurrentComponent,
    MentordetailsComponent,
    MentorsignupComponent,
    PayComponent,
    UserComponent,
    UsersignupComponent,
    LoginpageComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
