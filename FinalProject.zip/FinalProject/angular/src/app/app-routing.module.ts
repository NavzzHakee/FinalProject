import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainpageComponent } from './mainpage/mainpage.component';
import { AdminComponent } from './admin/admin.component';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminmentordataComponent } from './adminmentordata/adminmentordata.component';
import { AdmintechnoComponent } from './admintechno/admintechno.component';
import { AdminuserdataComponent } from './adminuserdata/adminuserdata.component';
import { CompleteddetailsComponent } from './completeddetails/completeddetails.component';
import { CoursedetailsComponent } from './coursedetails/coursedetails.component';
import { CurrentdetailsComponent } from './currentdetails/currentdetails.component';
import { DevelopmentComponent } from './development/development.component';
import { EditskillComponent } from './editskill/editskill.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { MendorComponent } from './mendor/mendor.component';
import { MentorcompComponent } from './mentorcomp/mentorcomp.component';
import { MentorcurrentComponent } from './mentorcurrent/mentorcurrent.component';
import { MentordetailsComponent } from './mentordetails/mentordetails.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { PayComponent } from './pay/pay.component';
import { UserComponent } from './user/user.component';
import { UsersignupComponent } from './usersignup/usersignup.component';


const routes: Routes = [
  { path:'',component:MainpageComponent},
  {path:'admin',component:AdminComponent},
  { path:'admindetails/:username',component:AdmindetailsComponent},
  { path:'adminmentordata',component:AdminmentordataComponent},
  { path:'admintechno',component:AdmintechnoComponent},
 { path:'adminuserdata',component:AdminuserdataComponent},
 { path:'completeddetails',component:CompleteddetailsComponent},
 { path:'coursedetails/:username',component:CoursedetailsComponent},
 { path:'currentdetails',component:CurrentdetailsComponent},
 { path:'development',component:DevelopmentComponent},
 { path:'editskill',component:EditskillComponent},
 { path:'loginpage',component:LoginpageComponent},
 { path:'mendor',component:MendorComponent},
 { path:'mentorcomp',component:MentorcompComponent},
 { path:'mentorcurrent',component:MentorcurrentComponent},
 { path:'mentordetails/:username',component:MentordetailsComponent},
 { path:'mentorsignup',component:MentorsignupComponent},
 { path:'pay',component:PayComponent},
 { path:'user',component:UserComponent},
 { path:'usersignup',component:UsersignupComponent}
 







];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
