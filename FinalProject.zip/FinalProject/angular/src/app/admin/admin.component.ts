import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  email :string;
  password : string;

  constructor(private admin : Router) { }

  ngOnInit() {
  }
  submit() {
    if(this.email==null) {
      alert("Enter email address");
    }else if(this.password==null) {
      alert("Enter password");
    }else {
      this.admin.navigate(['/admindetails']);
    }
  }

}
