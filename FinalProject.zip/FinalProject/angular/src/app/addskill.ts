export class Adminmainpage{
    skillid:Int16Array;
    skillname:string;
}