import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { ServiceuserService } from '../serviceuser.service';
@Component({
  selector: 'app-coursedetails',
  templateUrl: './coursedetails.component.html',
  styleUrls: ['./coursedetails.component.css']
})
export class CoursedetailsComponent implements OnInit {
  constructor(private user:ServiceuserService){}

  print:number=0;
  private mentor:string[];
  
  
  
 

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.user.getmentor().subscribe(value=>this.mentor=value as string[]);

    
  }
  // constructor(private httpservice : HttpClient) { }

  // course : string[];
  // call: number = 0;
  
  // ngOnInit() {
  //   this.httpservice.get('../../assets/development.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }
  myFunction() {
    var input, filter, table, tr, td, td1, i, txtValue, txtValue1;
   input = document.getElementById("myInput");
   filter = input.value.toUpperCase();
   table = document.getElementById("myTable");
   tr = table.getElementsByTagName("tr");
   for (i = 0; i < tr.length; i++) {
     td = tr[i].getElementsByTagName("td")[2];
     td1 = tr[i].getElementsByTagName("td")[1];
     if (td!=null || td1!=null) {
      txtValue = td.textContent || td.innerText;
      txtValue1 = td1.textContent || td1.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1 || txtValue1.toUpperCase().indexOf(filter) > -1) tr[i].style.display = ""; 
      else tr[i].style.display = "none";
     }    
    }
  }
  myfunction() { 
    this.print = 1;
  }
}