import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentdetailsComponent } from './currentdetails.component';

describe('CurrentdetailsComponent', () => {
  let component: CurrentdetailsComponent;
  let fixture: ComponentFixture<CurrentdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
