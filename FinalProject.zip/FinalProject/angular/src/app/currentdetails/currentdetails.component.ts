import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Currentdetails } from '../user';
import { ServiceuserService} from '../serviceuser.service';
@Component({
  selector: 'app-currentdetails',
  templateUrl: './currentdetails.component.html',
  styleUrls: ['./currentdetails.component.css']
})
export class CurrentdetailsComponent implements OnInit {

  // constructor(private httpservice : HttpClient) { }

  // course : string[];


  // ngOnInit() {
  //   this.httpservice.get('../../assets/current.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }
  private technology=[];

  constructor(private user:ServiceuserService){}

  private mcurrent:string[];
  
  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    
    this.user.getcurrent().subscribe(value=>this.mcurrent=value as string[]);
  }

}
