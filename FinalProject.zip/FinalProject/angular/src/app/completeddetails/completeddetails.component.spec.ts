import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteddetailsComponent } from './completeddetails.component';

describe('CompleteddetailsComponent', () => {
  let component: CompleteddetailsComponent;
  let fixture: ComponentFixture<CompleteddetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteddetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteddetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
