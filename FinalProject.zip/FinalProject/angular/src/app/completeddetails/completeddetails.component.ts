import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { ServiceuserService} from '../serviceuser.service';
import { Currentdetails } from '../user';
@Component({
  selector: 'app-completeddetails',
  templateUrl: './completeddetails.component.html',
  styleUrls: ['./completeddetails.component.css']
})
export class CompleteddetailsComponent implements OnInit {

  // constructor(private httpservice : HttpClient) { }

  // course : string[];


  // ngOnInit() {
  //   this.httpservice.get('../../assets/complete.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }
  private technology=[];

  constructor(private user:ServiceuserService){}
  private mcompleted:string[];
  
  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
   
    this.user.getcompleted().subscribe(value=>this.mcompleted=value as string[]);
   
  }


}