export class Currentdetails{
    trainername: string;
    course: string;
    completion: Int16Array;
}