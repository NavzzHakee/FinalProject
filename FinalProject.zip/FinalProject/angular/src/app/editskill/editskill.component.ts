
import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Router } from '@angular/router';
import {ServiceuserService} from '../serviceuser.service';
// import {Adminmainpage} from '../addskill';
@Component({
  selector: 'app-editskill',
  templateUrl: './editskill.component.html',
  styleUrls: ['./editskill.component.css']
})
export class EditskillComponent implements OnInit {

  
  adminmainprint:number = 0;
  adder:string;
  minus:string;
  
  discount:  number = 0;
  addprice: number = 0;
  
  private technologies: string[];
  private users: string[];
  private mentor: string[];
  
  constructor(private httpservice : ServiceuserService,private router: Router) {
   }

   ngOnInit() {
    this.showtech();
    this.reloadData();
  }
    


  

   onSubmitt()
  {
    if(this.adder!=""){
    this.httpservice.savetechnology(this.adder).subscribe(data=>console.log(data),error=>console.log(error));
    this.adder = "";
    } 
    if(this.minus!=""){
    this.httpservice.removetechnology(this.minus).subscribe(data=>console.log(data),error=>console.log(error));
    this.minus = "";
    }
  }

  showtech(){
    this.httpservice.displaytechnology().subscribe(value=>this.technologies=value as string[]);
  }

  reloadData() {
    this.httpservice.getblockusers().subscribe(value=>this.mentor=value as string[]);
  }

  

  tech(){
    this.adminmainprint = 1;
  }

  editt(){
    this.adminmainprint = 2;
  }
  report(){
    this.adminmainprint = 3;
  }
  goback(){
   
    this.router.navigate(['/login']);
  }
  price(){
    this.discount = 0;
    this.addprice = 0;
  }
}
