import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminmentordataComponent } from './adminmentordata.component';

describe('AdminmentordataComponent', () => {
  let component: AdminmentordataComponent;
  let fixture: ComponentFixture<AdminmentordataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminmentordataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminmentordataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
