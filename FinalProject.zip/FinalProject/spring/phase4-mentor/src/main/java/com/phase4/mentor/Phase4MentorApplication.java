package com.phase4.mentor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;


@EnableEurekaClient
@SpringBootApplication
public class Phase4MentorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase4MentorApplication.class, args);
	}

}
