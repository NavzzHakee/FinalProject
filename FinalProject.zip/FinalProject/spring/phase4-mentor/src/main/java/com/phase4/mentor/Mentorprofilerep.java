package com.phase4.mentor;

import javax.validation.Valid;

import org.springframework.data.repository.CrudRepository;

public interface Mentorprofilerep extends CrudRepository<Mentorprofile, Integer> {



}
