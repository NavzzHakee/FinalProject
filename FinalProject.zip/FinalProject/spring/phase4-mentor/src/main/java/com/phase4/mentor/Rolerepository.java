package com.phase4.mentor;

import org.springframework.data.repository.CrudRepository;

public interface Rolerepository extends CrudRepository<Role, Integer> {

}
