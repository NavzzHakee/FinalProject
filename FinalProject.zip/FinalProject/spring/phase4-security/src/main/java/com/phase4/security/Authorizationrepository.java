package com.phase4.security;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.data.repository.CrudRepository;

import com.phase4.security.Authorization;

public interface Authorizationrepository extends CrudRepository<Authorization, Integer> {

	Authorization findByUsername(@Valid String username);
	
}
