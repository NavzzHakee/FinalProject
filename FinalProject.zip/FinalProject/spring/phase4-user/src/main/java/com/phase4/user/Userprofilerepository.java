package com.phase4.user;

import org.springframework.data.repository.CrudRepository;

public interface Userprofilerepository extends CrudRepository<Userprofile, Integer> {

}
