package com.phase4.user;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface Usertrainingrepository extends CrudRepository<Usertraining,Integer> {
 
}
